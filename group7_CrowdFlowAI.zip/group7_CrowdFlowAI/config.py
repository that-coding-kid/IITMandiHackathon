"""
Configuration module for the BhedChaal Crowd Analysis Dashboard.
Manages loading and saving of application settings.
"""

import os
import json
import streamlit as st

# Default configuration file path
CONFIG_FILE = "config.json"

# Default configuration
DEFAULT_CONFIG = {
    # Analysis settings
    "yolo_model_size": "x",          # YOLOv8 model size (n, s, m, l, x)
    "use_tracking": True,            # Enable person tracking
    "density_threshold": 0.2,        # Threshold for density point detection
    "max_points": 200,               # Maximum number of density points
    "anomaly_threshold": 30,         # Threshold for anomaly detection
    "stampede_threshold": 35,        # Threshold for stampede warning
    
    # Display settings
    "playback_speed": 1.0,           # Default video playback speed
    "show_heatmap": True,            # Show density heatmap
    "show_tracking": True,           # Show tracking lines
    "show_flow": True,               # Show flow visualization
    
    # Advanced settings
    "save_frequency": 20,            # Save data every N frames
    "preprocess_video": True,        # Preprocess videos before analysis
    "auto_record": False,            # Auto-record panic simulations
    "record_duration": 60,           # Duration of panic simulation recordings
    
    # System settings
    "debug_mode": False,             # Enable debug logging
    "auto_cleanup": False,           # Automatically clean up old files
    "cleanup_days": 7                # Number of days to keep files
}

def load_config():
    """Load configuration from the config file or initialize with defaults"""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
            # Merge with DEFAULT_CONFIG to ensure all fields exist
            for key, value in DEFAULT_CONFIG.items():
                if key not in config:
                    config[key] = value
            return config
        except Exception as e:
            print(f"Error loading config: {e}")
            return DEFAULT_CONFIG
    else:
        # Create a new config file with defaults
        with open(CONFIG_FILE, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4)
        return DEFAULT_CONFIG

def update_config(config_updates):
    """Update the configuration with new values and save to file"""
    config = load_config()
    
    # Update config with new values
    if isinstance(config_updates, dict):
        # Process multiple updates at once
        for key, value in config_updates.items():
            config[key] = value
    else:
        # Handle the legacy format (key, value)
        key = config_updates
        value = config_updates
        config[key] = value
    
    # Save updated config to file
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False

def get_config_value(key, default=None):
    """Get a specific configuration value with a fallback default"""
    config = load_config()
    return config.get(key, default)

def reset_config():
    """Reset configuration to defaults"""
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4)
        return True
    except Exception as e:
        print(f"Error resetting config: {e}")
        return False 