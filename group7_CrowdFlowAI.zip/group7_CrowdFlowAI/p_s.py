import os
import cv2
import numpy as np
import json
import math
import random
import time
from pathlib import Path
import argparse
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.animation import FuncAnimation

# Social Force Model parameters
class SocialForceParameters:
    def __init__(self):
        # Desired speed (normal conditions)
        self.v0 = 1.5  # m/s
        
        # Panic parameters
        self.panic_v0 = 3.0  # Desired speed during panic
        self.panic_repulsion = 2.0  # Increased repulsion during panic
        self.panic_spread_radius = 50  # Radius for panic spreading
        self.panic_spread_probability = 0.2  # Base probability for panic spreading
        
        # Time constant (how quickly agents adapt to desired velocity)
        self.tau = 0.5  # seconds
        
        # Agent body parameters
        self.agent_radius = 5  # pixels
        
        # Forces
        # Repulsive force between agents
        self.A = 2000  # strength (N)
        self.B = 0.08  # range (m)
        
        # Physical contact forces
        self.k1 = 1.2e5  # body force (kg/s²)
        self.k2 = 2.4e5  # friction force (kg/m/s)
        
        # Wall forces
        self.wall_A = 2000  # strength (N)
        self.wall_B = 0.08  # range (m)
        
        # Attractive forces (groups, destinations)
        self.C = 0.5  # strength for attraction to destination (N)
        self.group_force = 0.5  # strength of group cohesion

# Agent class for the simulation
class Agent:
    def __init__(self, id, position, params, walkable_areas, exits, is_density_point=False):
        self.id = id
        self.position = np.array(position, dtype=float)
        self.velocity = np.array([0.0, 0.0])
        self.desired_direction = np.array([0.0, 0.0])
        self.force = np.array([0.0, 0.0])
        self.params = params
        self.desired_speed = params.v0
        self.mass = 70 + 20 * random.random()  # 70-90 kg
        self.is_density_point = is_density_point
        self.panic_level = 0.0  # 0.0 to 1.0
        self.goal = None
        self.path = []  # Historical positions for visualization
        self.walkable_areas = walkable_areas
        self.exits = exits
        self.nearest_exit = self._find_nearest_exit()
        self.trapped = False
        self.escaped = False
        self.injury_level = 0.0  # 0.0 to 1.0
        self.fallen = False
        self.time_fallen = 0
        self.max_fallen_time = 50  # frames until agent can get up
        self.neighbors = []
    
    def update_desired_direction(self, agents):
        """Update agent's desired direction based on exits, obstacles, and panic level"""
        if self.fallen:
            self.desired_direction = np.array([0.0, 0.0])
            return
            
        if self.escaped:
            self.desired_direction = np.array([0.0, 0.0])
            return
            
        # Find nearest exit and set as goal
        if self.panic_level > 0.1 and self.nearest_exit is not None:
            exit_direction = self.nearest_exit - self.position
            distance = np.linalg.norm(exit_direction)
            if distance > 0:
                self.desired_direction = exit_direction / distance
                
                # Check if agent has reached exit
                if distance < 20:
                    self.escaped = True
                    self.panic_level = 0
                    return
        else:
            # Normal behavior when not panicked - random movement
            if random.random() < 0.01 or np.linalg.norm(self.desired_direction) < 0.1:
                angle = 2 * math.pi * random.random()
                self.desired_direction = np.array([math.cos(angle), math.sin(angle)])
                
        # Adjust desired speed based on panic level
        self.desired_speed = (1 - self.panic_level) * self.params.v0 + self.panic_level * self.params.panic_v0
    
    def _find_nearest_exit(self):
        """Find the nearest exit to this agent"""
        if not self.exits:
            return None
            
        min_dist = float('inf')
        nearest = None
        
        for exit_pos in self.exits:
            dist = np.linalg.norm(np.array(exit_pos) - self.position)
            if dist < min_dist:
                min_dist = dist
                nearest = np.array(exit_pos)
                
        return nearest
    
    def update_panic(self, agents, panic_source=None):
        """Update agent's panic level based on neighbors and external factors"""
        # Direct panic from source
        if panic_source is not None:
            distance_to_source = np.linalg.norm(self.position - panic_source)
            if distance_to_source < self.params.panic_spread_radius:
                # The closer to the source, the higher the panic
                direct_panic = max(0, 1.0 - distance_to_source / self.params.panic_spread_radius)
                self.panic_level = max(self.panic_level, direct_panic)
        
        # Panic spreading from other agents
        for other in agents:
            if other.id != self.id and other.panic_level > 0.5:
                distance = np.linalg.norm(self.position - other.position)
                if distance < self.params.panic_spread_radius:
                    # Probability increases with other's panic level and proximity
                    spread_probability = self.params.panic_spread_probability * other.panic_level * (1 - distance / self.params.panic_spread_radius)
                    if random.random() < spread_probability:
                        new_panic = other.panic_level * 0.9  # Slightly lower than source
                        self.panic_level = max(self.panic_level, new_panic)
        
        # Panic increases with injury
        self.panic_level = max(self.panic_level, self.injury_level)
        
        # Panic decay
        if not self.fallen and panic_source is None:
            self.panic_level = max(0, self.panic_level - 0.01)
            
        # Cap panic level
        self.panic_level = min(1.0, self.panic_level)
        
    def calculate_social_forces(self, agents, walls):
        """Calculate the social forces acting on this agent"""
        if self.fallen or self.escaped:
            self.force = np.array([0.0, 0.0])
            return
            
        # Desired force (agent wants to move at desired speed in desired direction)
        desired_velocity = self.desired_direction * self.desired_speed
        desired_force = (desired_velocity - self.velocity) * self.mass / self.params.tau
        
        # Agent-agent repulsive forces
        agent_repulsive_force = np.array([0.0, 0.0])
        self.neighbors = []
        
        for other in agents:
            if other.id != self.id and not other.escaped:
                # Calculate distance and direction to other agent
                r_ij = self.position - other.position
                dist = np.linalg.norm(r_ij)
                
                # Skip if too far away
                if dist > 50:  # Only consider nearby agents
                    continue
                    
                # Add to neighbors for later use
                self.neighbors.append(other)
                
                # Skip if no actual distance (prevent division by zero)
                if dist < 0.1:
                    continue
                
                # Direction from other to self
                e_ij = r_ij / dist
                
                # Adjusted parameter for panic
                repulsion_factor = 1.0 + self.panic_level * self.params.panic_repulsion
                
                # Social repulsion
                social_force = self.params.A * repulsion_factor * math.exp((2 * self.params.agent_radius - dist) / self.params.B) * e_ij
                
                # Physical forces if agents touch
                if dist < 2 * self.params.agent_radius:
                    # Normal force (body force)
                    normal_force = self.params.k1 * (2 * self.params.agent_radius - dist) * e_ij
                    
                    # Calculate tangential direction
                    tangential = np.array([-e_ij[1], e_ij[0]])
                    
                    # Relative tangential velocity
                    delta_v_tangential = np.dot(self.velocity - other.velocity, tangential)
                    
                    # Friction force
                    friction_force = self.params.k2 * (2 * self.params.agent_radius - dist) * delta_v_tangential * tangential
                    
                    # Add physical forces
                    social_force += normal_force - friction_force
                    
                    # Apply higher injury risk in dense, panicked crowds
                    if self.panic_level > 0.5 and len(self.neighbors) > 5:
                        injury_risk = 0.01 * self.panic_level * len(self.neighbors) / 10.0
                        if random.random() < injury_risk:
                            self.injury_level += 0.1
                            # Check if agent falls
                            if self.injury_level > 0.7 and not self.fallen:
                                self.fallen = True
                                self.time_fallen = 0
                
                agent_repulsive_force += social_force
        
        # Wall forces
        wall_force = np.array([0.0, 0.0])
        for wall in walls:
            # Calculate distance and direction to wall
            dist, normal = self._distance_to_wall(wall)
            
            # Skip if too far away
            if dist > 20:
                continue
                
            # Wall repulsion
            wall_repulsion = self.params.wall_A * math.exp((self.params.agent_radius - dist) / self.params.wall_B)
            wall_force += wall_repulsion * normal
            
            # Physical forces if agent touches wall
            if dist < self.params.agent_radius:
                # Normal force
                normal_force = self.params.k1 * (self.params.agent_radius - dist) * normal
                wall_force += normal_force
                
                # Apply injury chance in panic situations
                if self.panic_level > 0.7 and random.random() < 0.01:
                    self.injury_level += 0.05
        
        # Attraction to exit during panic
        exit_force = np.array([0.0, 0.0])
        if self.panic_level > 0.3 and self.nearest_exit is not None:
            exit_dir = self.nearest_exit - self.position
            dist = np.linalg.norm(exit_dir)
            if dist > 0:
                exit_dir = exit_dir / dist
                exit_force = self.params.C * exit_dir
        
        # Sum all forces
        panic_multiplier = 1.0 + 0.5 * self.panic_level  # Forces are stronger during panic
        self.force = desired_force + panic_multiplier * (agent_repulsive_force + wall_force) + exit_force
    
    def _distance_to_wall(self, wall):
        """Calculate distance to a wall segment and the normal vector"""
        p1, p2 = np.array(wall[0]), np.array(wall[1])
        p3 = self.position
        
        # Vector from p1 to p2
        line_vec = p2 - p1
        line_length = np.linalg.norm(line_vec)
        line_unitvec = line_vec / line_length if line_length > 0 else np.array([0.0, 0.0])
        
        # Vector from p1 to p3
        point_vec = p3 - p1
        
        # Project point_vec onto line_vec
        t = np.dot(point_vec, line_unitvec)
        
        # Get closest point on line
        if t < 0:
            closest = p1
        elif t > line_length:
            closest = p2
        else:
            closest = p1 + line_unitvec * t
        
        # Distance and normal
        dist_vec = p3 - closest
        distance = np.linalg.norm(dist_vec)
        normal = dist_vec / distance if distance > 0 else np.array([0.0, 0.0])
        
        return distance, normal
    
    def update_position(self, dt):
        """Update agent position based on calculated forces"""
        if self.fallen:
            # Fallen agents don't move but can recover after some time
            self.time_fallen += 1
            if self.time_fallen > self.max_fallen_time:
                self.fallen = False
                if random.random() < 0.5:  # 50% chance of recovery
                    self.injury_level = max(0, self.injury_level - 0.3)
            return
            
        if self.escaped:
            return
            
        # Calculate acceleration (F = ma)
        acceleration = self.force / self.mass
        
        # Update velocity
        self.velocity += acceleration * dt
        
        # Cap velocity based on panic level
        max_speed = self.params.v0 + self.panic_level * (self.params.panic_v0 - self.params.v0)
        current_speed = np.linalg.norm(self.velocity)
        if current_speed > max_speed:
            self.velocity = self.velocity * max_speed / current_speed
        
        # Calculate new position
        new_position = self.position + self.velocity * dt
        
        # Check if new position is in a walkable area
        if self._is_position_walkable(new_position):
            self.position = new_position
        else:
            # If not walkable, try to slide along obstacles
            # First try moving only in x direction
            x_position = np.array([new_position[0], self.position[1]])
            if self._is_position_walkable(x_position):
                self.position = x_position
                self.velocity[1] = 0  # Zero out y velocity
            else:
                # Then try moving only in y direction
                y_position = np.array([self.position[0], new_position[1]])
                if self._is_position_walkable(y_position):
                    self.position = y_position
                    self.velocity[0] = 0  # Zero out x velocity
                else:
                    # Otherwise, stay in place
                    self.velocity = np.array([0.0, 0.0])
        
        # Record path for visualization
        if len(self.path) > 20:
            self.path.pop(0)
        self.path.append(self.position.copy())
    
    def _is_position_walkable(self, position):
        """Check if a position is within walkable areas"""
        # Check against walkable polygons first
        for area in self.walkable_areas:
            area_points = np.array(area)
            if self._point_in_polygon(position, area_points):
                return True
        
        return False
    
    def _point_in_polygon(self, point, polygon):
        """Ray casting algorithm to determine if a point is in a polygon"""
        x, y = point
        n = len(polygon)
        inside = False
        
        p1x, p1y = polygon[0]
        for i in range(1, n + 1):
            p2x, p2y = polygon[i % n]
            if y > min(p1y, p2y):
                if y <= max(p1y, p2y):
                    if x <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                        if p1x == p2x or x <= xinters:
                            inside = not inside
            p1x, p1y = p2x, p2y
            
        return inside

class StampedeSimulation:
    def __init__(self, video_data_dir="video_data", video_id=None):
        self.params = SocialForceParameters()
        self.video_data_dir = video_data_dir
        self.video_id = video_id
        self.agents = []
        self.walkable_areas = []
        self.roads = []
        self.exits = []
        self.walls = []
        self.size = (800, 600)
        self.panic_source = None
        self.panic_active = False
        
        # Simulation metadata
        self.time = 0
        self.dt = 0.1  # time step in seconds
        self.frame_count = 0
        
        # Visualization
        self.density_grid = np.zeros((60, 80))  # grid for density calculation
        self.grid_size = 10  # size of each density grid cell
        
        # Stats
        self.total_agents = 0
        self.escaped_agents = 0
        self.fallen_agents = 0
        self.avg_panic = 0.0
        
        # Figure and animation
        self.fig = None
        self.animation = None
    
    def load_simulation_data(self):
        """Load areas, perspective points, and agents from video data"""
        self._load_areas()
        self._generate_walls_from_areas()
        self._define_exits()
        
        # Load object and density data
        objects = self._load_object_data()
        density_points = self._load_density_data()
        
        # Create agents from data
        self._create_agents_from_data(objects, density_points)
        
        self.total_agents = len(self.agents)
        
        print(f"Loaded {len(self.walkable_areas)} walkable areas, {len(self.roads)} roads")
        print(f"Generated {len(self.walls)} wall segments")
        print(f"Defined {len(self.exits)} exits")
        print(f"Created {len(self.agents)} agents ({len(objects)} from objects, {len(density_points)} from density points)")
    
    def _load_areas(self):
        """Load walkable areas and roads from saved data"""
        if not self.video_id:
            # Find the first area file if no specific ID
            areas_dir = os.path.join(self.video_data_dir, "areas")
            area_files = [f for f in os.listdir(areas_dir) if f.endswith('.json')]
            if not area_files:
                raise ValueError("No area files found in video_data/areas directory")
            
            # Use the first file found
            self.video_id = area_files[0].split('_')[1].split('.')[0]
            print(f"Using video ID: {self.video_id}")
        
        # Load area file
        area_file = os.path.join(self.video_data_dir, "areas", f"areas_{self.video_id}.json")
        if not os.path.exists(area_file):
            raise ValueError(f"Area file not found: {area_file}")
        
        with open(area_file, 'r') as f:
            areas_data = json.load(f)
        
        self.walkable_areas = [area for area in areas_data.get("walking_areas", [])]
        self.roads = [road for road in areas_data.get("roads", [])]
    
    def _generate_walls_from_areas(self):
        """Generate wall segments from the boundaries of walkable areas and roads"""
        # Process walkable areas
        for area in self.walkable_areas:
            for i in range(len(area)):
                self.walls.append([area[i], area[(i+1) % len(area)]])
        
        # Process roads
        for road in self.roads:
            for i in range(len(road)):
                self.walls.append([road[i], road[(i+1) % len(road)]])
    
    def _define_exits(self):
        """Define exits based on the walkable areas and roads"""
        # Automatically place exits at the edges of walkable areas
        # In a real implementation, these would be manually defined
        for area in self.walkable_areas:
            # Find extreme points of the area
            xs = [p[0] for p in area]
            ys = [p[1] for p in area]
            max_x, min_x = max(xs), min(xs)
            max_y, min_y = max(ys), min(ys)
            
            # Place exits at midpoints of edges if near the boundary of the simulation
            width, height = self.size
            margin = 100
            
            # Left edge
            if min_x < margin:
                self.exits.append([min_x, (max_y + min_y) / 2])
            
            # Right edge
            if max_x > width - margin:
                self.exits.append([max_x, (max_y + min_y) / 2])
            
            # Top edge
            if min_y < margin:
                self.exits.append([(max_x + min_x) / 2, min_y])
            
            # Bottom edge
            if max_y > height - margin:
                self.exits.append([(max_x + min_x) / 2, max_y])
        
        # Remove duplicates and keep only a reasonable number of exits
        if self.exits:
            filtered_exits = []
            min_distance = 100  # Minimum distance between exits
            
            for exit_pos in self.exits:
                # Check if this exit is too close to any already kept
                too_close = False
                for kept_exit in filtered_exits:
                    if np.linalg.norm(np.array(exit_pos) - np.array(kept_exit)) < min_distance:
                        too_close = True
                        break
                
                if not too_close:
                    filtered_exits.append(exit_pos)
            
            self.exits = filtered_exits[:4]  # Limit to maximum 4 exits
        else:
            # Default exits if none were found
            width, height = self.size
            self.exits = [
                [width/2, 0],            # Top center
                [width/2, height],       # Bottom center
                [0, height/2],           # Left center
                [width, height/2]        # Right center
            ]
    
    def _load_object_data(self):
        """Load object data from saved files"""
        objects_dir = os.path.join(self.video_data_dir, "objects")
        prefix = f"objects_{self.video_id}_frame_"
        
        # Find the last frame with object data
        object_files = [f for f in os.listdir(objects_dir) if f.startswith(prefix) and f.endswith('.json')]
        if not object_files:
            return []
        
        # Sort files by frame number and get the last one
        object_files.sort(key=lambda f: int(f[len(prefix):-5]))
        latest_file = object_files[-1]
        
        # Load the object data
        with open(os.path.join(objects_dir, latest_file), 'r') as f:
            data = json.load(f)
        
        return data.get("objects", [])
    
    def _load_density_data(self):
        """Load density point data from saved files"""
        density_dir = os.path.join(self.video_data_dir, "density")
        prefix = f"density_{self.video_id}_frame_"
        
        # Find the last frame with density data
        density_files = [f for f in os.listdir(density_dir) if f.startswith(prefix) and f.endswith('.json')]
        if not density_files:
            return []
        
        # Sort files by frame number and get the last one
        density_files.sort(key=lambda f: int(f[len(prefix):-5]))
        latest_file = density_files[-1]
        
        # Load the density data
        with open(os.path.join(density_dir, latest_file), 'r') as f:
            data = json.load(f)
        
        # Filter to only include points of type "density_point"
        return [point for point in data.get("density_points", []) 
                if point.get("type", "") == "density_point" or "density_value" in point]
    
    def _create_agents_from_data(self, objects, density_points):
        """Create agent objects from loaded data"""
        # Create agents from detected objects
        for i, obj in enumerate(objects):
            if "top_view" in obj:
                position = obj["top_view"]
                is_in_walkable = any(self._point_in_polygon(position, np.array(area)) for area in self.walkable_areas)
                
                if is_in_walkable:
                    agent = Agent(
                        id=obj.get("id", f"O{i}"), 
                        position=position,
                        params=self.params,
                        walkable_areas=self.walkable_areas,
                        exits=self.exits,
                        is_density_point=False
                    )
                    self.agents.append(agent)
        
        # Create agents from density points (fewer, as these often represent areas rather than individuals)
        sample_rate = 0.3  # Only create agents from 30% of density points
        for i, point in enumerate(density_points):
            if random.random() < sample_rate and "top_view" in point:
                position = point["top_view"]
                density_value = point.get("density_value", 0.5)
                
                # Skip points with very low density
                if density_value < 0.2:
                    continue
                
                is_in_walkable = any(self._point_in_polygon(position, np.array(area)) for area in self.walkable_areas)
                
                if is_in_walkable:
                    agent = Agent(
                        id=f"D{i}", 
                        position=position,
                        params=self.params,
                        walkable_areas=self.walkable_areas,
                        exits=self.exits,
                        is_density_point=True
                    )
                    # Higher density points might represent multiple people
                    if density_value > 0.7 and random.random() < 0.5:
                        # Add another agent nearby
                        nearby_position = [
                            position[0] + random.uniform(-10, 10),
                            position[1] + random.uniform(-10, 10)
                        ]
                        if any(self._point_in_polygon(nearby_position, np.array(area)) for area in self.walkable_areas):
                            nearby_agent = Agent(
                                id=f"D{i}b", 
                                position=nearby_position,
                                params=self.params,
                                walkable_areas=self.walkable_areas,
                                exits=self.exits,
                                is_density_point=True
                            )
                            self.agents.append(nearby_agent)
                    
                    self.agents.append(agent)
    
    def _point_in_polygon(self, point, polygon):
        """Check if a point is inside a polygon"""
        x, y = point
        n = len(polygon)
        inside = False
        
        p1x, p1y = polygon[0]
        for i in range(1, n + 1):
            p2x, p2y = polygon[i % n]
            if y > min(p1y, p2y):
                if y <= max(p1y, p2y):
                    if x <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                        if p1x == p2x or x <= xinters:
                            inside = not inside
            p1x, p1y = p2x, p2y
            
        return inside
    
    def set_panic_source(self, position):
        """Set a position as the source of panic"""
        self.panic_source = np.array(position)
        self.panic_active = True
        print(f"Panic source set at {position}")
        
        # Cause immediate panic for nearby agents
        for agent in self.agents:
            distance = np.linalg.norm(agent.position - self.panic_source)
            if distance < self.params.panic_spread_radius:
                # Direct panic inversely proportional to distance
                agent.panic_level = max(agent.panic_level, 1.0 - distance / self.params.panic_spread_radius)
    
    def update(self):
        """Update the simulation state"""
        self.frame_count += 1
        self.time += self.dt
        
        # Update agent desires and panic
        for agent in self.agents:
            agent.update_desired_direction(self.agents)
            agent.update_panic(self.agents, self.panic_source if self.panic_active else None)
        
        # Calculate forces
        for agent in self.agents:
            agent.calculate_social_forces(self.agents, self.walls)
        
        # Update positions
        for agent in self.agents:
            agent.update_position(self.dt)
        
        # Update stats
        self.escaped_agents = sum(1 for agent in self.agents if agent.escaped)
        self.fallen_agents = sum(1 for agent in self.agents if agent.fallen)
        if self.agents:
            self.avg_panic = sum(agent.panic_level for agent in self.agents) / len(self.agents)
        
        # Update density grid
        self._update_density_grid()
    
    def _update_density_grid(self):
        """Update density grid for visualization"""
        # Reset grid
        self.density_grid = np.zeros((self.size[1] // self.grid_size, self.size[0] // self.grid_size))
        
        # Count agents in each grid cell
        for agent in self.agents:
            if not agent.escaped:
                grid_x = int(min(agent.position[0] // self.grid_size, self.density_grid.shape[1] - 1))
                grid_y = int(min(agent.position[1] // self.grid_size, self.density_grid.shape[0] - 1))
                self.density_grid[grid_y, grid_x] += 1
        
        # Normalize and apply smoothing
        if np.max(self.density_grid) > 0:
            # Apply Gaussian smoothing
            from scipy.ndimage import gaussian_filter
            self.density_grid = gaussian_filter(self.density_grid, sigma=1.0)
    
    def run_simulation(self, num_steps=1000):
        """Run the simulation for a specified number of steps"""
        for _ in range(num_steps):
            self.update()
            if self.frame_count % 100 == 0:
                print(f"Step {self.frame_count}: {self.escaped_agents} escaped, {self.fallen_agents} fallen, avg panic: {self.avg_panic:.2f}")
            
            if self.escaped_agents + self.fallen_agents >= len(self.agents) * 0.9:
                print("Simulation ended: 90% of agents have either escaped or fallen")
                break
    
    def setup_visualization(self):
        """Set up the visualization figure and axes"""
        self.fig, self.ax = plt.subplots(figsize=(12, 9))
        plt.subplots_adjust(left=0.05, right=0.95, top=0.95, bottom=0.05)
        
        # Create custom colormap for density
        colors = [(0, 0, 0.5), (0, 0, 1), (0, 1, 1), (0, 1, 0), (1, 1, 0), (1, 0, 0)]
        n_bins = 100
        self.cmap = LinearSegmentedColormap.from_list('density_cmap', colors, N=n_bins)
        
        # Initialize visualization elements
        self.density_plot = self.ax.imshow(
            np.zeros_like(self.density_grid),
            extent=(0, self.size[0], self.size[1], 0),
            cmap=self.cmap,
            alpha=0.5,
            vmin=0, vmax=5
        )
        
        # Draw walkable areas
        for area in self.walkable_areas:
            area_array = np.array(area)
            self.ax.fill(area_array[:, 0], area_array[:, 1], color='green', alpha=0.2)
            self.ax.plot(area_array[:, 0], area_array[:, 1], color='green', alpha=0.5, linewidth=2)
        
        # Draw roads
        for road in self.roads:
            road_array = np.array(road)
            self.ax.fill(road_array[:, 0], road_array[:, 1], color='blue', alpha=0.2)
            self.ax.plot(road_array[:, 0], road_array[:, 1], color='blue', alpha=0.5, linewidth=2)
        
        # Draw walls
        for wall in self.walls:
            wall_array = np.array(wall)
            self.ax.plot(wall_array[:, 0], wall_array[:, 1], color='black', linewidth=1)
        
        # Draw exits
        for exit_pos in self.exits:
            self.ax.plot(exit_pos[0], exit_pos[1], 'r*', markersize=15)
            self.ax.text(exit_pos[0] + 10, exit_pos[1] + 10, 'EXIT', color='red', fontsize=12)
        
        # Initialize scatter plots for different agent states
        self.normal_agents = self.ax.scatter([], [], s=50, c='blue', alpha=0.8, edgecolors='black', label='Normal')
        self.panicked_agents = self.ax.scatter([], [], s=50, c='red', alpha=0.8, edgecolors='black', label='Panicked')
        self.fallen_agents = self.ax.scatter([], [], s=50, c='gray', alpha=0.8, edgecolors='black', label='Fallen')
        self.escaped_agents = self.ax.scatter([], [], s=50, c='green', alpha=0.8, edgecolors='black', label='Escaped')
        
        # Initialize paths
        self.paths = []
        
        # Add legend and title
        self.ax.legend(loc='upper right')
        self.ax.set_title("Panic/Stampede Simulation")
        
        # Add stats text
        self.stats_text = self.ax.text(
            0.02, 0.02, "", transform=self.ax.transAxes,
            fontsize=10, verticalalignment='bottom', bbox=dict(boxstyle='round', facecolor='white', alpha=0.5)
        )
        
        # Set axis limits
        self.ax.set_xlim(0, self.size[0])
        self.ax.set_ylim(self.size[1], 0)  # Invert y-axis for image coordinates
    
    def init_animation(self):
        """Initialize animation elements"""
        self.normal_agents.set_offsets(np.empty((0, 2)))
        self.panicked_agents.set_offsets(np.empty((0, 2)))
        self.fallen_agents.set_offsets(np.empty((0, 2)))
        self.escaped_agents.set_offsets(np.empty((0, 2)))
        
        # Clear existing paths
        for path in self.paths:
            if path in self.ax.lines:
                path.remove()
        self.paths = []
        
        # Reset density plot
        self.density_plot.set_array(np.zeros_like(self.density_grid))
        
        # Reset stats text
        self.stats_text.set_text("")
        
        return self.normal_agents, self.panicked_agents, self.fallen_agents, self.escaped_agents, self.density_plot, self.stats_text
    
    def update_animation(self, frame):
        """Update animation elements for each frame"""
        # Update simulation
        self.update()
        
        # Update density plot
        self.density_plot.set_array(self.density_grid)
        
        # Sort agents by state
        normal_positions = []
        panicked_positions = []
        fallen_positions = []
        escaped_positions = []
        
        # Clear existing paths
        for path in self.paths:
            if path in self.ax.lines:
                path.remove()
        self.paths = []
        
        # Update agent positions and paths
        for agent in self.agents:
            pos = agent.position
            
            # Draw path for agents with significant movement
            if len(agent.path) > 1:
                path_array = np.array(agent.path)
                path, = self.ax.plot(path_array[:, 0], path_array[:, 1], 
                                    color='red' if agent.panic_level > 0.5 else 'blue', 
                                    alpha=0.5, linewidth=1)
                self.paths.append(path)
            
            # Sort by state
            if agent.escaped:
                escaped_positions.append(pos)
            elif agent.fallen:
                fallen_positions.append(pos)
            elif agent.panic_level > 0.5:
                panicked_positions.append(pos)
            else:
                normal_positions.append(pos)
        
        # Update scatter plots
        self.normal_agents.set_offsets(np.array(normal_positions) if normal_positions else np.empty((0, 2)))
        self.panicked_agents.set_offsets(np.array(panicked_positions) if panicked_positions else np.empty((0, 2)))
        self.fallen_agents.set_offsets(np.array(fallen_positions) if fallen_positions else np.empty((0, 2)))
        self.escaped_agents.set_offsets(np.array(escaped_positions) if escaped_positions else np.empty((0, 2)))
        
        # If panic source exists, highlight it
        if self.panic_source is not None and self.panic_active:
            # Check if panic source marker already exists
            if not hasattr(self, 'panic_marker'):
                self.panic_marker = self.ax.plot(self.panic_source[0], self.panic_source[1], 'ro', markersize=20, alpha=0.5)[0]
                self.panic_text = self.ax.text(self.panic_source[0] + 15, self.panic_source[1] + 15, 
                                             "PANIC SOURCE", color='red', fontsize=12, 
                                             bbox=dict(facecolor='white', alpha=0.7))
        
        # Update stats text
        self.stats_text.set_text(
            f"Time: {self.time:.1f}s | Agents: {len(self.agents)} | " +
            f"Normal: {len(normal_positions)} | Panicked: {len(panicked_positions)} | " +
            f"Fallen: {len(fallen_positions)} | Escaped: {len(escaped_positions)} | " +
            f"Avg Panic: {self.avg_panic:.2f}"
        )
        
        return self.normal_agents, self.panicked_agents, self.fallen_agents, self.escaped_agents, self.density_plot, self.stats_text
    
    def start_animation(self, frames=500, interval=50):
        """Start the animation"""
        print("Setting up visualization...")
        self.setup_visualization()
        
        print(f"Starting animation with {frames} frames...")
        self.animation = FuncAnimation(
            self.fig, self.update_animation, frames=frames,
            init_func=self.init_animation, blit=True, interval=interval
        )
        
        # Set up panic source on click
        def on_click(event):
            if event.inaxes == self.ax:
                self.set_panic_source([event.xdata, event.ydata])
        
        self.fig.canvas.mpl_connect('button_press_event', on_click)
        
        plt.show()
    
    def save_animation(self, filename="panic_simulation.mp4"):
        """Save the animation to a file"""
        if self.animation is None:
            print("No animation to save. Run start_animation first.")
            return
        
        print(f"Saving animation to {filename}...")
        self.animation.save(filename, writer='ffmpeg', fps=20, dpi=100)
        print(f"Animation saved to {filename}")


def create_panic_simulation_from_video(video_path, output_dir=None):
    """Create a panic simulation from a video's analysis data"""
    # Import required modules
    from visualization import AreaManager, get_perspective_transform
    import os
    
    # Setup for data extraction
    video_id = None
    area_manager = AreaManager(video_path=video_path, save_dir="video_data")
    
    # Try to load areas
    if area_manager.load_areas():
        print("Successfully loaded areas from saved data")
        # Extract video ID from the area manager
        if hasattr(area_manager, 'video_id'):
            video_id = area_manager.video_id
    else:
        print("Error: No saved area data found for this video")
        return None
    
    # Create simulation
    simulation = StampedeSimulation(video_data_dir="video_data", video_id=video_id)
    simulation.load_simulation_data()
    
    # Create output directory if provided
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"panic_simulation_{video_id}.mp4")
    else:
        output_file = f"panic_simulation_{video_id}.mp4"
    
    # Start interactive visualization
    print("Starting interactive visualization...")
    print("Click anywhere on the simulation to set a panic source!")
    simulation.start_animation(frames=1000, interval=50)
    
    # Save animation
    simulation.save_animation(output_file)
    
    return simulation


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Panic/Stampede Simulation from CCTV Analysis")
    parser.add_argument("--video", type=str, default=None,
                        help="Path to input video (to find saved data)")
    parser.add_argument("--video_id", type=str, default=None,
                        help="Video ID to use (alternative to --video)")
    parser.add_argument("--data_dir", type=str, default="video_data",
                        help="Directory containing video data")
    parser.add_argument("--output", type=str, default=None,
                        help="Output directory for saving simulation")
    parser.add_argument("--panic_source", type=float, nargs=2, default=None,
                        help="Initial panic source coordinates (x y)")
    parser.add_argument("--frames", type=int, default=1000,
                        help="Number of frames to simulate")
    parser.add_argument("--interactive", action="store_true", default=True,
                        help="Run in interactive mode with visualization")
    parser.add_argument("--save_video", action="store_true", default=False,
                        help="Save animation as video")
    
    args = parser.parse_args()
    
    # Handle input options
    if args.video:
        sim = create_panic_simulation_from_video(args.video, args.output)
    else:
        # Create simulation directly
        sim = StampedeSimulation(video_data_dir=args.data_dir, video_id=args.video_id)
        sim.load_simulation_data()
        
        # Set panic source if provided
        if args.panic_source:
            sim.set_panic_source(args.panic_source)
        
        # Run interactive or non-interactive
        if args.interactive:
            print("Starting interactive visualization...")
            print("Click anywhere on the simulation to set a panic source!")
            sim.start_animation(frames=args.frames, interval=50)
        else:
            print("Running non-interactive simulation...")
            sim.run_simulation(num_steps=args.frames)
        
        # Save animation if requested
        if args.save_video:
            output_file = f"panic_simulation_{sim.video_id}.mp4" if sim.video_id else "panic_simulation.mp4"
            if args.output:
                os.makedirs(args.output, exist_ok=True)
                output_file = os.path.join(args.output, output_file)
            
            sim.save_animation(output_file)