#!/usr/bin/env python3
"""
BhedChaal - Crowd Monitoring System
Run script to start the application
"""

import os
import subprocess
import sys

def check_requirements():
    """Check if all required packages are installed"""
    try:
        import streamlit
        import cv2
        import numpy
        from streamlit_drawable_canvas import st_canvas
        return True
    except ImportError as e:
        print(f"Missing dependency: {e}")
        return False

def install_requirements():
    """Install required packages using pip"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error installing requirements: {e}")
        return False

def create_directories():
    """Create necessary directories"""
    directories = [
        "uploaded_videos",
        "processed_videos",
        "video_data",
        "video_data/areas",
        "video_data/perspective",
        "video_data/objects",
        "video_data/density",
        "video_data/anomalies",
        "thumbnails"
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    
    print("Created necessary directories")

def run_app():
    """Run the Streamlit application"""
    try:
        # Check if app.py exists
        if not os.path.exists("app.py"):
            print("Error: app.py not found")
            return False
        
        # Start Streamlit server
        print("Starting BhedChaal application...")
        subprocess.run([
            sys.executable, "-m", "streamlit", "run", "app.py",
            "--server.port", "8501",
            "--browser.serverAddress", "localhost",
            "--server.headless", "false",
            "--browser.gatherUsageStats", "false"
        ])
        
        return True
    except Exception as e:
        print(f"Error running application: {e}")
        return False

if __name__ == "__main__":
    print("BhedChaal - Crowd Monitoring System")
    print("-----------------------------------")
    
    # Check requirements
    print("Checking requirements...")
    if not check_requirements():
        print("Installing missing dependencies...")
        if not install_requirements():
            print("Error: Failed to install requirements. Please install them manually.")
            sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Run the application
    run_app() 