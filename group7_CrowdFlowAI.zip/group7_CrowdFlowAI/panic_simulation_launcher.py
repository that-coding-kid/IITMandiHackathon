#!/usr/bin/env python
"""
Launcher for panic/stampede simulation based on real-world crowd footage
"""

import os
import sys
import subprocess
import argparse
import time

def check_dependencies():
    """Check if required dependencies are installed"""
    missing_deps = []
    
    try:
        import pygame
    except ImportError:
        missing_deps.append("pygame")
    
    try:
        import cv2
    except ImportError:
        missing_deps.append("opencv-python")
    
    try:
        import numpy
    except ImportError:
        missing_deps.append("numpy")
    
    try:
        from scipy import ndimage
    except ImportError:
        missing_deps.append("scipy")
    
    if missing_deps:
        print("Missing dependencies:")
        for dep in missing_deps:
            print(f"  - {dep}")
        
        # Ask user if they want to install missing dependencies
        print("\nWould you like to install the missing dependencies? (y/n)")
        response = input().lower()
        
        if response in ['y', 'yes']:
            for dep in missing_deps:
                print(f"Installing {dep}...")
                subprocess.call([sys.executable, "-m", "pip", "install", dep])
            print("Dependencies installed.")
            return True
        else:
            print("Dependencies required. Cannot proceed.")
            return False
    
    return True

def run_cctv_processing(args):
    """Run the CCTV to top view processing to generate data"""
    from main import process_cctv_to_top_view, enhanced_process_cctv_to_top_view
    
    print("Processing video to generate data...")
    
    # Run in enhanced mode to generate density points
    if args.enhanced:
        result = enhanced_process_cctv_to_top_view(
            args.video_path,
            args.output,
            args.calibration,
            use_tracking=not args.no_tracking,
            yolo_model_size=args.model_size,
            csrnet_model_path=args.csrnet_weights,
            density_threshold=args.density_threshold,
            max_points=args.max_points,
            preprocess_video=not args.no_preprocess,
            anomaly_threshold=args.anomaly_threshold,
            stampede_threshold=args.stampede_threshold,
            max_bottlenecks=args.max_bottlenecks
        )
    else:
        result = process_cctv_to_top_view(
            args.video_path,
            args.output,
            args.calibration,
            use_tracking=not args.no_tracking,
            yolo_model_size=args.model_size,
            csrnet_model_path=args.csrnet_weights,
            preprocess_video=not args.no_preprocess,
            anomaly_threshold=args.anomaly_threshold,
            stampede_threshold=args.stampede_threshold,
            max_bottlenecks=args.max_bottlenecks
        )
    
    print("Processing complete.")
    return result

def run_panic_simulation(video_path, auto_record=False, record_duration=60):
    """Run the panic simulation using the video data
    
    Args:
        video_path: Path to the video file
        auto_record: Whether to automatically start recording
        record_duration: Duration of the recording in seconds
    """
    print("Launching panic simulation...")
    
    # Import the panic simulation module directly for better control
    try:
        # First, try to import directly
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        from panic_simulation import PanicSimulation
        
        # Create simulation instance
        simulation = PanicSimulation()
        
        # Load data
        if simulation.load_data_from_video(video_path):
            # Auto-start recording if requested
            if auto_record:
                print(f"Auto-recording enabled for {record_duration} seconds")
                simulation.start_recording(duration=record_duration)
            
            # Run simulation
            simulation.run_simulation()
            return True
        else:
            print(f"Failed to load data from {video_path}")
            return False
    except ImportError:
        # Fall back to subprocess call
        print("Falling back to subprocess call...")
        try:
            cmd = [sys.executable, "panic_simulation.py", video_path]
            # No way to pass auto_record parameter in this mode
            subprocess.call(cmd)
            return True
        except Exception as e:
            print(f"Error running panic simulation: {e}")
            return False

def main():
    """Main function for launching panic simulation"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Launch panic/stampede simulation based on real-world crowd footage')
    parser.add_argument('--video-path', '-v', type=str, default=None,
                        help='Path to input video file')
    parser.add_argument('--output', '-o', type=str, default=None,
                        help='Path for output file (default: None, only display)')
    parser.add_argument('--calibration', '-c', type=str, default=None,
                        help='Path to calibration image (default: use first frame)')
    parser.add_argument('--model-size', '-m', type=str, default='x', choices=['n', 's', 'm', 'l', 'x'],
                        help='YOLOv8 model size (default: x)')
    parser.add_argument('--csrnet-weights', '-w', type=str, default=None,
                        help='Path to CSRNet weights (default: use built-in default)')
    parser.add_argument('--no-tracking', action='store_true',
                        help='Disable person tracking (default: tracking enabled)')
    parser.add_argument('--enhanced', '-e', action='store_true',
                        help='Use enhanced visualization with density points (default: True)')
    parser.add_argument('--density-threshold', type=float, default=0.2,
                        help='Threshold for density-based data points (default: 0.2)')
    parser.add_argument('--max-points', type=int, default=200,
                        help='Maximum number of density points (default: 200)')
    parser.add_argument('--no-preprocess', action='store_true',
                        help='Disable video preprocessing/standardization (default: preprocessing enabled)')
    parser.add_argument('--anomaly-threshold', type=int, default=30,
                        help='Threshold for bottleneck detection (default: 30)')
    parser.add_argument('--stampede-threshold', type=int, default=35,
                        help='Threshold for stampede warning (default: 35)')
    parser.add_argument('--max-bottlenecks', type=int, default=3,
                        help='Maximum number of bottlenecks to identify (default: 3)')
    parser.add_argument('--skip-processing', action='store_true',
                        help='Skip video processing and use existing data')
    parser.add_argument('--auto-record', action='store_true',
                        help='Automatically start recording animation when simulation begins')
    parser.add_argument('--record-duration', type=int, default=60,
                        help='Duration of auto-recording in seconds (default: 60)')
    
    args = parser.parse_args()
    
    # Enable enhanced mode by default
    if not args.enhanced:
        args.enhanced = True
    
    # Set default video path if not provided
    if args.video_path is None:
        # Find first video file in current directory
        for file in os.listdir('.'):
            if file.endswith('.mp4'):
                args.video_path = file
                break
        
        if args.video_path is None:
            print("Error: No video file specified and no .mp4 files found in current directory.")
            return 1
    
    # Check if video file exists
    if not os.path.exists(args.video_path):
        print(f"Error: Video file '{args.video_path}' not found.")
        return 1
    
    # Check dependencies
    if not check_dependencies():
        return 1
    
    # Process video if not skipped
    if not args.skip_processing:
        result = run_cctv_processing(args)
        if not result:
            print("Video processing failed.")
            return 1
        
        # Give some time for the processing windows to close
        print("Waiting for processing to complete...")
        time.sleep(2)
    
    # Run panic simulation
    success = run_panic_simulation(args.video_path, args.auto_record, args.record_duration)
    
    if success:
        print("Panic simulation completed.")
        return 0
    else:
        print("Panic simulation failed.")
        return 1

if __name__ == "__main__":
    # Set environment variables for OpenCV to avoid conflicts with older CUDA libraries
    os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
    
    # Run the main function
    exit_code = main()
    exit(exit_code) 