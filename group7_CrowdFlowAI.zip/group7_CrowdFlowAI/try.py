#!/usr/bin/env python
"""
Launcher script for integrating panic/stampede simulation with crowd analysis system
"""

import os
import cv2
import numpy as np
import argparse
import signal
import sys
import threading
import time
from pathlib import Path

# Import for crowd analysis
from visualization import process_cctv_to_top_view
from simulation_enhancement import enhanced_process_cctv_to_top_view

# Import panic simulation
from panic_simulation import StampedeSimulation, create_panic_simulation_from_video

# Global flags for controlling the simulation flow
analyzing_video = True
panic_simulation_ready = False
video_path = None
video_id = None

def signal_handler(sig, frame):
    """Handle Ctrl+C to properly clean up resources"""
    print("\nExiting gracefully...")
    cv2.destroyAllWindows()
    sys.exit(0)

def on_key_press(key_code):
    """Handle key presses during video analysis"""
    global analyzing_video, panic_simulation_ready
    
    if key_code == ord('p'):  # 'p' key to trigger panic simulation
        print("\n--- Transitioning to Panic Simulation ---")
        analyzing_video = False
        panic_simulation_ready = True
        # Close all OpenCV windows
        cv2.destroyAllWindows()
        return True
    
    return False

def run_panic_simulation(video_path, output_dir=None):
    """Run the panic simulation based on data from the video analysis"""
    print("\nInitializing panic simulation...")
    try:
        # Create a panic simulation based on the analyzed video
        simulation = create_panic_simulation_from_video(video_path, output_dir)
        
        if simulation is None:
            print("Failed to create panic simulation. No data available for this video.")
            return
        
        # Save a baseline simulation for comparison
        output_file = f"panic_simulation_{simulation.video_id}.mp4" if simulation.video_id else "panic_simulation.mp4"
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            output_file = os.path.join(output_dir, output_file)
        
        print(f"\nPanic simulation complete. Output saved to: {output_file}")
        
    except Exception as e:
        print(f"Error in panic simulation: {e}")
        import traceback
        traceback.print_exc()

def launch_crowd_analysis_and_simulation():
    """Main function to launch the integrated system"""
    parser = argparse.ArgumentParser(description='Integrated Crowd Analysis and Panic Simulation')
    
    # Video analysis options
    parser.add_argument('--video-path', '-v', type=str, default=None,
                        help='Path to input video file')
    parser.add_argument('--output', '-o', type=str, default=None,
                        help='Path for output directory')
    parser.add_argument('--calibration', '-c', type=str, default=None,
                        help='Path to calibration image (default: use first frame)')
    parser.add_argument('--model-size', '-m', type=str, default='x', choices=['n', 's', 'm', 'l', 'x'],
                        help='YOLOv8 model size (default: x)')
    parser.add_argument('--enhanced', '-e', action='store_true',
                        help='Use enhanced visualization with density points (default: False)')
    parser.add_argument('--no-tracking', action='store_true',
                        help='Disable person tracking (default: tracking enabled)')
    
    # Simulation options
    parser.add_argument('--skip-analysis', '-s', action='store_true',
                        help='Skip video analysis and go directly to panic simulation')
    parser.add_argument('--video-id', '-id', type=str, default=None,
                        help='Video ID for direct simulation (use with --skip-analysis)')
    parser.add_argument('--panic-source', '-p', type=float, nargs=2, default=None,
                        help='Initial panic source coordinates (x y) for simulation')
    
    args = parser.parse_args()
    
    global video_path, video_id
    video_path = args.video_path
    
    # Skip analysis if requested
    if args.skip_analysis:
        if args.video_id:
            video_id = args.video_id
            simulation = StampedeSimulation(video_data_dir="video_data", video_id=video_id)
            simulation.load_simulation_data()
            
            # Set panic source if provided
            if args.panic_source:
                simulation.set_panic_source(args.panic_source)
            
            print("Starting panic simulation directly...")
            print("Click anywhere on the simulation to set a panic source!")
            simulation.start_animation(frames=1000, interval=50)
            
            if args.output:
                output_file = os.path.join(args.output, f"panic_simulation_{video_id}.mp4")
                simulation.save_animation(output_file)
            
            return
        else:
            print("Error: --video-id is required when using --skip-analysis")
            return
    
    # Check if video file exists
    if not args.video_path:
        print("Error: No video path specified. Use --video-path")
        return
    
    if not os.path.exists(args.video_path):
        print(f"Error: Video file '{args.video_path}' not found.")
        return
    
    # Register signal handler for Ctrl+C
    signal.signal(signal.SIGINT, signal_handler)
    
    print("\n--- Crowd Analysis and Panic Simulation ---")
    print("Press 'p' during video analysis to transition to panic simulation")
    print("Press 'q' to quit at any time\n")
    
    # Add key event monitoring
    def key_monitor():
        global analyzing_video
        while analyzing_video:
            key = cv2.waitKey(100) & 0xFF
            if key == ord('q'):
                analyzing_video = False
                cv2.destroyAllWindows()
                print("\nExiting...")
                os._exit(0)  # Force exit
            elif on_key_press(key):
                break
            time.sleep(0.1)
    
    # Start key monitoring in a separate thread
    key_thread = threading.Thread(target=key_monitor)
    key_thread.daemon = True
    key_thread.start()
    
    try:
        # Run video analysis based on the enhanced flag
        print("Starting video analysis...")
        if args.enhanced:
            enhanced_process_cctv_to_top_view(
                args.video_path,
                args.output,
                args.calibration,
                use_tracking=not args.no_tracking,
                yolo_model_size=args.model_size,
                save_data=True
            )
        else:
            process_cctv_to_top_view(
                args.video_path,
                args.output,
                args.calibration,
                use_tracking=not args.no_tracking,
                yolo_model_size=args.model_size,
                save_data=True
            )
        
        # Check if panic simulation was triggered during analysis
        if panic_simulation_ready:
            run_panic_simulation(args.video_path, args.output)
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Make sure all OpenCV windows are closed
        cv2.destroyAllWindows()

if __name__ == "__main__":
    launch_crowd_analysis_and_simulation()