import streamlit as st
import cv2
import numpy as np
from streamlit_drawable_canvas import st_canvas
import json
import os
from utils import get_video_id, DATA_DIR, save_areas_data, save_perspective_data

def get_first_frame(video_path):
    """Get the first frame of a video file"""
    if not os.path.exists(video_path):
        return None
    
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return None
    
    ret, frame = cap.read()
    cap.release()
    
    if not ret:
        return None
    
    # Convert BGR to RGB for Streamlit
    return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

def draw_walking_areas(video_path):
    """Allow user to draw walking areas using Streamlit canvas"""
    video_id = get_video_id(video_path)
    
    # Get first frame for canvas background
    frame = get_first_frame(video_path)
    if frame is None:
        st.error("Could not read the video file.")
        return None
    
    height, width = frame.shape[:2]
    
    st.subheader("Define Walking Areas")
    st.write("Draw polygons to define walking areas (green). Press Submit when done.")
    
    # Use Streamlit's columns for layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Create a drawable canvas with the first frame as background
        canvas_result = st_canvas(
            fill_color="rgba(0, 255, 0, 0.3)",
            stroke_width=2,
            stroke_color="#00FF00",
            background_image=frame,
            height=height,
            width=width,
            drawing_mode="polygon",
            key="walking_areas_canvas",
        )
    
    with col2:
        st.write("Instructions:")
        st.write("1. Click to place points")
        st.write("2. Complete the polygon by clicking on the first point")
        st.write("3. Draw multiple areas if needed")
        st.write("4. When finished, press Submit")
    
    # Extract walking areas from canvas
    walking_areas = []
    if canvas_result.json_data is not None:
        canvas_data = canvas_result.json_data
        for obj in canvas_data.get("objects", []):
            if obj.get("type") == "polygon":
                points = obj.get("points", [])
                area = [(int(p.get("x")), int(p.get("y"))) for p in points]
                if len(area) >= 3:  # Only include valid polygons
                    walking_areas.append(area)
    
    return walking_areas

def draw_roads(video_path, walking_areas=None):
    """Allow user to draw roads using Streamlit canvas"""
    video_id = get_video_id(video_path)
    
    # Get first frame for canvas background
    frame = get_first_frame(video_path)
    if frame is None:
        st.error("Could not read the video file.")
        return None
    
    height, width = frame.shape[:2]
    
    # Draw existing walking areas on the frame if provided
    if walking_areas:
        overlay = frame.copy()
        for area in walking_areas:
            area_np = np.array(area, dtype=np.int32)
            cv2.fillPoly(overlay, [area_np], (0, 255, 0, 128))
        frame = cv2.addWeighted(overlay, 0.5, frame, 0.5, 0)
    
    st.subheader("Define Roads")
    st.write("Draw polygons to define roads (blue). Press Submit when done.")
    
    # Use Streamlit's columns for layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Create a drawable canvas with the first frame as background
        canvas_result = st_canvas(
            fill_color="rgba(0, 0, 255, 0.3)",
            stroke_width=2,
            stroke_color="#0000FF",
            background_image=frame,
            height=height,
            width=width,
            drawing_mode="polygon",
            key="roads_canvas",
        )
    
    with col2:
        st.write("Instructions:")
        st.write("1. Click to place points")
        st.write("2. Complete the polygon by clicking on the first point")
        st.write("3. Draw multiple roads if needed")
        st.write("4. When finished, press Submit")
    
    # Extract roads from canvas
    roads = []
    if canvas_result.json_data is not None:
        canvas_data = canvas_result.json_data
        for obj in canvas_data.get("objects", []):
            if obj.get("type") == "polygon":
                points = obj.get("points", [])
                road = [(int(p.get("x")), int(p.get("y"))) for p in points]
                if len(road) >= 3:  # Only include valid polygons
                    roads.append(road)
    
    return roads

def define_perspective_points(video_path):
    """Allow user to define 4 perspective points using Streamlit canvas"""
    video_id = get_video_id(video_path)
    
    # Get first frame for canvas background
    frame = get_first_frame(video_path)
    if frame is None:
        st.error("Could not read the video file.")
        return None
    
    height, width = frame.shape[:2]
    
    st.subheader("Define Perspective Transform Points")
    st.write("Mark 4 points to define perspective transformation. Points should be marked in this order:")
    st.write("1. Top-Left")
    st.write("2. Top-Right")
    st.write("3. Bottom-Right")
    st.write("4. Bottom-Left")
    
    # Use Streamlit's columns for layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Create a drawable canvas for perspective points
        canvas_result = st_canvas(
            fill_color="rgba(255, 0, 0, 0.3)",
            stroke_width=2,
            stroke_color="#FF0000",
            background_image=frame,
            height=height,
            width=width,
            drawing_mode="point",
            point_display_radius=5,
            key="perspective_canvas",
        )
    
    with col2:
        st.write("Make sure to place points in the correct order as shown.")
        st.write("These points will define the perspective transformation for top-down view.")
    
    # Extract perspective points from canvas
    perspective_points = []
    if canvas_result.json_data is not None:
        canvas_data = canvas_result.json_data
        for obj in canvas_data.get("objects", []):
            if obj.get("type") == "circle":
                x = int(obj.get("left", 0) + obj.get("radius", 0))
                y = int(obj.get("top", 0) + obj.get("radius", 0))
                perspective_points.append([x, y])
    
    # Check if we have exactly 4 points
    if len(perspective_points) != 4:
        st.warning(f"Please define exactly 4 points. You currently have {len(perspective_points)} points.")
        return None
    
    return perspective_points

def setup_video_preprocessing(video_path):
    """Allow user to define all preprocessing parameters for a video"""
    video_id = get_video_id(video_path)
    
    st.header(f"Video Preprocessing Setup: {os.path.basename(video_path)}")
    
    # Initialize session state for this function if not already done
    if 'preprocessing_step' not in st.session_state:
        st.session_state.preprocessing_step = 0
    if 'walking_areas' not in st.session_state:
        st.session_state.walking_areas = None
    if 'roads' not in st.session_state:
        st.session_state.roads = None
    if 'perspective_points' not in st.session_state:
        st.session_state.perspective_points = None
    
    # Check if we already have saved data and load it if available
    areas_file = os.path.join(DATA_DIR, "areas", f"areas_{video_id}.json")
    perspective_file = os.path.join(DATA_DIR, "perspective", f"perspective_{video_id}.json")
    
    if os.path.exists(areas_file) and st.session_state.walking_areas is None:
        try:
            with open(areas_file, 'r') as f:
                areas_data = json.load(f)
                st.session_state.walking_areas = areas_data.get("walking_areas", [])
                st.session_state.roads = areas_data.get("roads", [])
        except Exception as e:
            st.error(f"Error loading areas data: {e}")
    
    if os.path.exists(perspective_file) and st.session_state.perspective_points is None:
        try:
            with open(perspective_file, 'r') as f:
                perspective_data = json.load(f)
                st.session_state.perspective_points = perspective_data.get("perspective_points", [])
        except Exception as e:
            st.error(f"Error loading perspective data: {e}")
    
    # Define tabs for different steps
    tabs = st.tabs(["1. Walking Areas", "2. Roads", "3. Perspective Points", "4. Review"])
    
    # Set active tab based on session state
    active_tab = st.session_state.preprocessing_step
    
    # Tab 1: Walking Areas
    with tabs[0]:
        if active_tab == 0:
            if st.session_state.walking_areas:
                st.success("Walking areas already defined. You can redefine them if needed.")
                show_existing = st.checkbox("Show existing walking areas", True)
                
                if show_existing:
                    # Display the existing walking areas
                    frame = get_first_frame(video_path)
                    if frame is not None:
                        for area in st.session_state.walking_areas:
                            area_np = np.array(area, dtype=np.int32)
                            cv2.fillPoly(frame, [area_np], (0, 255, 0, 128))
                        st.image(frame, caption="Existing Walking Areas")
                
                if st.button("Redefine Walking Areas"):
                    areas = draw_walking_areas(video_path)
                    if areas is not None:
                        st.session_state.walking_areas = areas
                
                if st.button("Next Step", key="next_to_roads"):
                    st.session_state.preprocessing_step = 1
                    st.rerun()
            else:
                areas = draw_walking_areas(video_path)
                if areas is not None:
                    st.session_state.walking_areas = areas
                    if st.button("Continue to Roads"):
                        st.session_state.preprocessing_step = 1
                        st.rerun()
    
    # Tab 2: Roads
    with tabs[1]:
        if active_tab == 1:
            if st.session_state.roads:
                st.success("Roads already defined. You can redefine them if needed.")
                show_existing = st.checkbox("Show existing roads", True)
                
                if show_existing:
                    # Display the existing roads
                    frame = get_first_frame(video_path)
                    if frame is not None:
                        for road in st.session_state.roads:
                            road_np = np.array(road, dtype=np.int32)
                            cv2.fillPoly(frame, [road_np], (0, 0, 255, 128))
                        st.image(frame, caption="Existing Roads")
                
                if st.button("Redefine Roads"):
                    roads = draw_roads(video_path, st.session_state.walking_areas)
                    if roads is not None:
                        st.session_state.roads = roads
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Previous Step", key="back_to_areas"):
                        st.session_state.preprocessing_step = 0
                        st.rerun()
                with col2:
                    if st.button("Next Step", key="next_to_perspective"):
                        st.session_state.preprocessing_step = 2
                        st.rerun()
            else:
                roads = draw_roads(video_path, st.session_state.walking_areas)
                if roads is not None:
                    st.session_state.roads = roads
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("Back to Walking Areas"):
                            st.session_state.preprocessing_step = 0
                            st.rerun()
                    with col2:
                        if st.button("Continue to Perspective Points"):
                            st.session_state.preprocessing_step = 2
                            st.rerun()
    
    # Tab 3: Perspective Points
    with tabs[2]:
        if active_tab == 2:
            if st.session_state.perspective_points and len(st.session_state.perspective_points) == 4:
                st.success("Perspective points already defined. You can redefine them if needed.")
                show_existing = st.checkbox("Show existing perspective points", True)
                
                if show_existing:
                    # Display the existing perspective points
                    frame = get_first_frame(video_path)
                    if frame is not None:
                        for i, point in enumerate(st.session_state.perspective_points):
                            cv2.circle(frame, tuple(point), 10, (255, 0, 0), -1)
                            cv2.putText(frame, str(i+1), (point[0]+15, point[1]), 
                                      cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                        st.image(frame, caption="Existing Perspective Points")
                
                if st.button("Redefine Perspective Points"):
                    points = define_perspective_points(video_path)
                    if points is not None:
                        st.session_state.perspective_points = points
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Previous Step", key="back_to_roads"):
                        st.session_state.preprocessing_step = 1
                        st.rerun()
                with col2:
                    if st.button("Review and Save", key="next_to_review"):
                        st.session_state.preprocessing_step = 3
                        st.rerun()
            else:
                points = define_perspective_points(video_path)
                if points is not None and len(points) == 4:
                    st.session_state.perspective_points = points
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("Back to Roads"):
                            st.session_state.preprocessing_step = 1
                            st.rerun()
                    with col2:
                        if st.button("Continue to Review"):
                            st.session_state.preprocessing_step = 3
                            st.rerun()
    
    # Tab 4: Review
    with tabs[3]:
        if active_tab == 3:
            st.subheader("Review and Save")
            
            # Display a summary of what's been defined
            if st.session_state.walking_areas:
                st.success(f"✅ Walking Areas: {len(st.session_state.walking_areas)} areas defined")
            else:
                st.error("❌ Walking Areas: Not defined")
            
            if st.session_state.roads:
                st.success(f"✅ Roads: {len(st.session_state.roads)} roads defined")
            else:
                st.error("❌ Roads: Not defined")
            
            if st.session_state.perspective_points and len(st.session_state.perspective_points) == 4:
                st.success("✅ Perspective Points: All 4 points defined")
            else:
                st.error("❌ Perspective Points: Not properly defined (need exactly 4 points)")
            
            # Show a composite image with all elements
            if st.session_state.walking_areas or st.session_state.roads or st.session_state.perspective_points:
                frame = get_first_frame(video_path)
                if frame is not None:
                    # Draw walking areas
                    if st.session_state.walking_areas:
                        for area in st.session_state.walking_areas:
                            area_np = np.array(area, dtype=np.int32)
                            cv2.fillPoly(frame, [area_np], (0, 255, 0, 128))
                            cv2.polylines(frame, [area_np], True, (0, 255, 0), 2)
                    
                    # Draw roads
                    if st.session_state.roads:
                        for road in st.session_state.roads:
                            road_np = np.array(road, dtype=np.int32)
                            cv2.fillPoly(frame, [road_np], (0, 0, 255, 128))
                            cv2.polylines(frame, [road_np], True, (0, 0, 255), 2)
                    
                    # Draw perspective points
                    if st.session_state.perspective_points:
                        for i, point in enumerate(st.session_state.perspective_points):
                            cv2.circle(frame, tuple(point), 10, (255, 0, 0), -1)
                            cv2.putText(frame, str(i+1), (point[0]+15, point[1]), 
                                      cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                    
                    st.image(frame, caption="Composite Review")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Back to Perspective Points"):
                    st.session_state.preprocessing_step = 2
                    st.rerun()
            
            # Save button
            with col2:
                if st.button("Save and Continue"):
                    if (st.session_state.walking_areas and 
                        st.session_state.roads and 
                        st.session_state.perspective_points and 
                        len(st.session_state.perspective_points) == 4):
                        
                        # Save walking areas and roads
                        save_areas_data(video_id, st.session_state.walking_areas, st.session_state.roads)
                        
                        # Save perspective points
                        save_perspective_data(video_id, st.session_state.perspective_points)
                        
                        st.success("All preprocessing data saved successfully!")
                        
                        # Print debug message to console
                        print("DEBUG: Preprocessing complete, returning True")
                        
                        # Reset session state for next time
                        st.session_state.preprocessing_step = 0
                        st.session_state.walking_areas = None
                        st.session_state.roads = None
                        st.session_state.perspective_points = None
                        
                        # Set a success flag in session state
                        st.session_state.preprocessing_complete = True
                        
                        # Return True to indicate preprocessing is complete
                        return True
                    else:
                        st.error("Please complete all preprocessing steps before saving.")
                        return False
    
    # Set which tab should be active based on session state
    # This is just for visual feedback as the actual active content is controlled by the if statements
    active_tab_script = f"""
    <script>
        // This script attempts to click on the tab corresponding to the current step
        document.addEventListener('DOMContentLoaded', (event) => {{
            // Small delay to ensure tab elements are rendered
            setTimeout(() => {{
                const tabs = document.querySelectorAll('[data-baseweb="tab"]');
                if (tabs.length >= {active_tab + 1}) {{
                    tabs[{active_tab}].click();
                }}
            }}, 100);
        }});
    </script>
    """
    st.markdown(active_tab_script, unsafe_allow_html=True)
    
    return False 