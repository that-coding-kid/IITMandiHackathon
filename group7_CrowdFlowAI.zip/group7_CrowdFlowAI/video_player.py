import streamlit as st
import os
import cv2
import time
import numpy as np
from utils import get_video_id, get_processed_video_paths, run_panic_simulation

def display_video_analysis(video_path):
    """Display the video analysis with synchronized players"""
    video_id = get_video_id(video_path)
    video_name = os.path.basename(video_path)
    
    st.title(f"Video Analysis: {video_name}")
    
    # Get processed video paths
    processed_videos = get_processed_video_paths(video_id, video_name)
    
    if not processed_videos:
        st.warning("No processed videos found. Please run the analysis first.")
        if st.button("Return to Gallery"):
            st.session_state.active_tab = "gallery"
            st.rerun()
        return
    
    # Create tabs for different views
    tabs = st.tabs(["Synchronized View", "Crowd Flow", "Analytics", "Simulation"])
    
    with tabs[0]:
        st.header("Synchronized Video View")
        
        # Video playback controls (shared across all videos)
        col1, col2, col3 = st.columns([1, 1, 1])
        
        with col1:
            play_button = st.button("▶️ Play/Pause", use_container_width=True)
        
        with col2:
            speed_options = {0.25: "0.25x", 0.5: "0.5x", 1.0: "1.0x", 1.5: "1.5x", 2.0: "2.0x"}
            playback_speed = st.selectbox(
                "Speed", 
                options=list(speed_options.keys()),
                format_func=lambda x: speed_options[x],
                index=2  # Default to 1.0x
            )
        
        with col3:
            restart_button = st.button("⏮️ Restart", use_container_width=True)
        
        # Display the videos in a synchronized view
        cols = st.columns(len(processed_videos))
        
        # Determine what videos we have
        has_original = "original" in processed_videos
        has_top_view = "top_view" in processed_videos
        has_density = "density" in processed_videos
        
        # Display each video with proper labels
        if has_original:
            with cols[0]:
                st.subheader("Original View")
                st.video(processed_videos["original"])
        
        if has_top_view:
            with cols[1 if has_original else 0]:
                st.subheader("Top-Down View")
                st.video(processed_videos["top_view"])
        
        if has_density:
            with cols[2 if has_original and has_top_view else 1 if has_original or has_top_view else 0]:
                st.subheader("Density Map")
                st.video(processed_videos["density"])
    
    with tabs[1]:
        st.header("Crowd Flow Analysis")
        
        # Display flow analysis if available
        if has_top_view:
            st.subheader("Top-Down View with Flow Vectors")
            st.video(processed_videos["top_view"])
            
            # Add mock flow visualization
            st.markdown("### Flow Heatmap")
            
            # Generate a mock heatmap for demonstration
            # In a real implementation, this would come from actual flow analysis
            flow_img = np.zeros((400, 600, 3), dtype=np.uint8)
            
            # Generate some random flow patterns (this is just a placeholder)
            # In a real implementation, this would be based on actual movement data
            center_x, center_y = 300, 200
            for y in range(400):
                for x in range(600):
                    # Distance from center
                    dx = x - center_x
                    dy = y - center_y
                    distance = np.sqrt(dx*dx + dy*dy)
                    
                    if distance < 150:
                        # Create a radial gradient
                        intensity = int(255 * (1 - distance/150))
                        
                        # Color based on direction (red->yellow->green)
                        angle = np.arctan2(dy, dx)
                        r = int(127 + 127 * np.cos(angle))
                        g = int(127 + 127 * np.sin(angle))
                        b = 50
                        
                        flow_img[y, x] = [b, g, r]
            
            # Display the mock flow visualization
            st.image(flow_img, caption="Crowd Flow Heatmap", use_column_width=True)
            
            # Add some mock metrics
            st.markdown("### Flow Metrics")
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Average Speed", "1.2 m/s", "0.1 m/s")
            with col2:
                st.metric("Flow Direction", "North-East", "45°")
            with col3:
                st.metric("Congestion Index", "32%", "-5%")
        else:
            st.info("Top-down view not available. Please run the analysis with the top-down view option enabled.")
    
    with tabs[2]:
        st.header("Crowd Analytics")
        
        # Mock analytics data
        # In a real implementation, this would be based on actual analysis results
        st.subheader("Crowd Density Over Time")
        
        # Create a time series chart for crowd density
        times = np.arange(0, 100)
        # Generate a mock density curve with some peaks
        densities = 20 + 15 * np.sin(times/10) + 5 * np.sin(times/3) + np.random.randn(100) * 3
        
        # Plot using Streamlit's built-in chart functions
        st.line_chart(densities)
        
        # Display detection metrics
        st.subheader("Detection Statistics")
        
        # Create columns for metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Peak Count", "127 people", "+15%")
            st.metric("Min Count", "43 people", "-8%")
        
        with col2:
            st.metric("Average Density", "0.28 people/m²", "+5%")
            st.metric("Peak Density", "0.71 people/m²", "+22%")
        
        with col3:
            st.metric("Duration", "2:34", "")
            st.metric("Frames Analyzed", "1,854", "")
        
        # Display any detected anomalies
        st.subheader("Detected Anomalies")
        
        # Mock anomaly data
        anomalies = [
            {"time": "0:35", "type": "Bottleneck", "severity": "Low", "location": "North entrance"},
            {"time": "1:12", "type": "Counter-flow", "severity": "Medium", "location": "Central area"},
            {"time": "1:58", "type": "High Density", "severity": "High", "location": "South exit"}
        ]
        
        # Display anomalies in a table
        st.table(anomalies)
    
    with tabs[3]:
        st.header("Panic Simulation")
        
        st.markdown("""
        Run a panic simulation based on this video's crowd distribution and environment.
        
        The simulation will open in a separate window and show how the crowd might behave in an emergency situation.
        """)
        
        # Simulation parameters
        st.subheader("Simulation Parameters")
        
        col1, col2 = st.columns(2)
        
        with col1:
            panic_level = st.slider("Panic Level", min_value=0.0, max_value=1.0, value=0.5, step=0.1)
            exit_count = st.slider("Number of Exits", min_value=1, max_value=4, value=2)
        
        with col2:
            obstacle_density = st.slider("Obstacle Density", min_value=0.0, max_value=1.0, value=0.3, step=0.1)
            population = st.slider("Population Multiplier", min_value=0.5, max_value=2.0, value=1.0, step=0.1)
        
        # Record options
        st.subheader("Recording Options")
        
        col1, col2 = st.columns(2)
        
        with col1:
            auto_record = st.checkbox("Auto-record Simulation", value=False)
        
        with col2:
            if auto_record:
                record_duration = st.slider("Recording Duration (seconds)", min_value=10, max_value=120, value=60, step=10)
            else:
                record_duration = 60  # Default value if auto-record is off
        
        # Run simulation button
        if st.button("Run Panic Simulation", use_container_width=True):
            st.info("Starting panic simulation... (A new window will open)")
            
            # Call the panic simulation function with selected parameters
            success = run_panic_simulation(
                video_path=video_path,
                auto_record=auto_record,
                record_duration=record_duration
            )
            
            if success:
                st.success("Panic simulation launched successfully!")
            else:
                st.error("Failed to launch panic simulation. Please check the console for errors.")
        
        # Show sample simulation output
        st.subheader("Sample Simulation Output")
        
        # Mock image of a simulation (this would be replaced with actual results)
        st.image("https://via.placeholder.com/800x400?text=Panic+Simulation+Example", 
                 caption="Example of panic simulation visualization",
                 use_column_width=True)

def get_video_frame(video_path, frame_number=0):
    """Get a specific frame from a video file"""
    if not os.path.exists(video_path):
        return None
    
    cap = cv2.VideoCapture(video_path)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    if frame_number >= total_frames:
        frame_number = 0
    
    # Set frame position
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
    
    # Read frame
    ret, frame = cap.read()
    cap.release()
    
    if ret:
        # Convert to RGB for display
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    else:
        return None 