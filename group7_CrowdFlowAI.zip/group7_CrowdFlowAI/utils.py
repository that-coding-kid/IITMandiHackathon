import os
import json
import hashlib
import numpy as np
import cv2
import streamlit as st
import subprocess
import time
from pathlib import Path

# Define constants
SUPPORTED_FORMATS = ["mp4", "avi", "mov", "mkv"]
UPLOAD_DIR = "uploaded_videos"
PROCESSED_DIR = "processed_videos"
DATA_DIR = "video_data"

def create_directories():
    """Create necessary directories if they don't exist"""
    for directory in [UPLOAD_DIR, PROCESSED_DIR, f"{DATA_DIR}/areas", 
                     f"{DATA_DIR}/perspective", f"{DATA_DIR}/objects", 
                     f"{DATA_DIR}/density", f"{DATA_DIR}/anomalies"]:
        os.makedirs(directory, exist_ok=True)

def get_video_id(video_path):
    """Generate a unique ID for a video based on path and file stats"""
    if os.path.exists(video_path):
        stats = os.stat(video_path)
        video_id = f"{os.path.basename(video_path)}_{stats.st_size}_{int(stats.st_mtime)}"
        return hashlib.md5(video_id.encode()).hexdigest()
    return None

def save_uploaded_file(uploaded_file):
    """Save an uploaded file to the upload directory and return the path"""
    create_directories()
    file_path = os.path.join(UPLOAD_DIR, uploaded_file.name)
    
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    return file_path

def get_video_metadata(video_path):
    """Get video metadata using OpenCV"""
    if not os.path.exists(video_path):
        return None
    
    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            return None
        
        # Get basic metadata
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = frame_count / fps if fps > 0 else 0
        
        # Get a thumbnail
        ret, frame = cap.read()
        thumbnail_path = None
        if ret:
            thumbnail_dir = "thumbnails"
            os.makedirs(thumbnail_dir, exist_ok=True)
            video_id = get_video_id(video_path)
            thumbnail_path = os.path.join(thumbnail_dir, f"{video_id}.jpg")
            cv2.imwrite(thumbnail_path, frame)
        
        cap.release()
        
        return {
            "width": width,
            "height": height,
            "fps": fps,
            "frame_count": frame_count,
            "duration": duration,
            "thumbnail_path": thumbnail_path
        }
    except Exception as e:
        print(f"Error getting video metadata: {e}")
        return None

def get_all_videos():
    """Get a list of all videos in the upload directory"""
    videos = []
    
    for filename in os.listdir(UPLOAD_DIR):
        file_path = os.path.join(UPLOAD_DIR, filename)
        if os.path.isfile(file_path) and filename.split('.')[-1].lower() in SUPPORTED_FORMATS:
            video_id = get_video_id(file_path)
            metadata = get_video_metadata(file_path)
            processed_status = check_video_processed(video_id)
            
            videos.append({
                "id": video_id,
                "name": filename,
                "path": file_path,
                "metadata": metadata,
                "processed": processed_status
            })
    
    return videos

def check_video_processed(video_id):
    """Check if a video has been processed before"""
    # Check for areas data
    areas_file = os.path.join(DATA_DIR, "areas", f"areas_{video_id}.json")
    areas_exist = os.path.exists(areas_file)
    
    # Check for perspective data
    perspective_file = os.path.join(DATA_DIR, "perspective", f"perspective_{video_id}.json")
    perspective_exists = os.path.exists(perspective_file)
    
    # Check for processed output videos
    pattern = f"*_{video_id}_*enhanced*.mp4"
    processed_videos = list(Path(PROCESSED_DIR).glob(pattern))
    
    # Check if we have the standard three videos
    has_top_view = any("top_view" in str(p) for p in processed_videos)
    has_original = any("original" in str(p) for p in processed_videos)
    has_density = any("density" in str(p) for p in processed_videos)
    
    return {
        "areas_defined": areas_exist,
        "perspective_defined": perspective_exists,
        "has_processed_videos": len(processed_videos) > 0,
        "top_view_video": has_top_view,
        "original_video": has_original,
        "density_video": has_density
    }

def read_areas_data(video_id):
    """Read previously defined walking areas and roads"""
    areas_file = os.path.join(DATA_DIR, "areas", f"areas_{video_id}.json")
    if os.path.exists(areas_file):
        with open(areas_file, 'r') as f:
            data = json.load(f)
        return data.get('walking_areas', []), data.get('roads', [])
    return [], []

def read_perspective_data(video_id):
    """Read previously defined perspective points"""
    perspective_file = os.path.join(DATA_DIR, "perspective", f"perspective_{video_id}.json")
    if os.path.exists(perspective_file):
        with open(perspective_file, 'r') as f:
            data = json.load(f)
        return data.get('perspective_points', [])
    return []

def save_areas_data(video_id, walking_areas, roads):
    """Save defined walking areas and roads"""
    areas_file = os.path.join(DATA_DIR, "areas", f"areas_{video_id}.json")
    data = {
        "video_id": video_id,
        "walking_areas": walking_areas,
        "roads": roads
    }
    
    os.makedirs(os.path.dirname(areas_file), exist_ok=True)
    with open(areas_file, 'w') as f:
        json.dump(data, f)

def save_perspective_data(video_id, perspective_points):
    """Save defined perspective points"""
    perspective_file = os.path.join(DATA_DIR, "perspective", f"perspective_{video_id}.json")
    data = {
        "video_id": video_id,
        "perspective_points": perspective_points
    }
    
    os.makedirs(os.path.dirname(perspective_file), exist_ok=True)
    with open(perspective_file, 'w') as f:
        json.dump(data, f)

def get_processed_video_paths(video_id, video_name):
    """Get paths to processed videos if they exist"""
    base_name = os.path.splitext(video_name)[0]
    
    top_view_path = os.path.join(PROCESSED_DIR, f"{base_name}_{video_id}_enhanced_top_view.mp4")
    original_path = os.path.join(PROCESSED_DIR, f"{base_name}_{video_id}_enhanced_original.mp4")
    density_path = os.path.join(PROCESSED_DIR, f"{base_name}_{video_id}_enhanced_density.mp4")
    
    results = {}
    if os.path.exists(top_view_path):
        results["top_view"] = top_view_path
    if os.path.exists(original_path):
        results["original"] = original_path
    if os.path.exists(density_path):
        results["density"] = density_path
    
    return results

def run_processing_pipeline(video_path, density_threshold=0.2, max_points=200, 
                           use_tracking=True, yolo_model_size='x', areas=None, 
                           perspective_points=None):
    """Run the processing pipeline with the given parameters"""
    try:
        from main import enhanced_process_cctv_to_top_view
    except ImportError:
        import traceback
        error_msg = traceback.format_exc()
        st.error(f"Error importing enhanced_process_cctv_to_top_view from main.py. Details:\n{error_msg}")
        return None
    
    # Get video information
    video_id = get_video_id(video_path)
    video_name = os.path.basename(video_path)
    base_name = os.path.splitext(video_name)[0]
    output_path = os.path.join(PROCESSED_DIR, f"{base_name}_{video_id}")
    
    # Create a status placeholder for progress updates
    status_placeholder = st.empty()
    status_placeholder.info("Loading saved preprocessing data...")
    
    # If areas and perspective points were not provided, load them from saved data
    if not areas or not perspective_points:
        # Load walking areas and roads
        areas_file = os.path.join(DATA_DIR, "areas", f"areas_{video_id}.json")
        if os.path.exists(areas_file):
            try:
                with open(areas_file, 'r') as f:
                    areas_data = json.load(f)
                    walking_areas = areas_data.get("walking_areas", [])
                    roads = areas_data.get("roads", [])
                    areas = (walking_areas, roads)
                    status_placeholder.success(f"Loaded areas data: {len(walking_areas)} walking areas, {len(roads)} roads")
            except Exception as e:
                status_placeholder.error(f"Error loading areas data: {e}")
                return None
        else:
            status_placeholder.error(f"Areas data not found for video: {video_name}")
            return None
        
        # Load perspective points
        perspective_file = os.path.join(DATA_DIR, "perspective", f"perspective_{video_id}.json")
        if os.path.exists(perspective_file):
            try:
                with open(perspective_file, 'r') as f:
                    perspective_data = json.load(f)
                    perspective_points = perspective_data.get("perspective_points", [])
                    status_placeholder.success(f"Loaded perspective points: {len(perspective_points)} points")
            except Exception as e:
                status_placeholder.error(f"Error loading perspective points: {e}")
                return None
        else:
            status_placeholder.error(f"Perspective data not found for video: {video_name}")
            return None
    
    # Start processing
    status_placeholder.info("Processing video... (this may take a while)")
    
    try:
        # Call the processing function with extended logging
        print(f"Processing video: {video_path}")
        print(f"Output path: {output_path}")
        print(f"Areas: {areas}")
        print(f"Perspective points: {perspective_points}")
        
        result = enhanced_process_cctv_to_top_view(
            video_path=video_path,
            output_path=output_path,
            calibration_image=None,  # Use first frame
            src_points=perspective_points,  # Pass perspective points directly
            use_tracking=use_tracking,
            yolo_model_size=yolo_model_size,
            density_threshold=density_threshold,
            max_points=max_points,
            save_data=True,
            load_saved_data=True,
            preprocess_video=True
        )
        
        if result:
            status_placeholder.success("Processing complete! View the results below.")
            return result
        else:
            status_placeholder.error("Processing failed to produce results.")
            return None
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        status_placeholder.error(f"Error during processing: {str(e)}")
        st.code(error_details, language="python")
        print(f"Error processing video: {e}")
        print(error_details)
        return None

def run_panic_simulation(video_path, auto_record=False, record_duration=60):
    """Run the panic simulation with the given video"""
    try:
        # Run the panic simulation using subprocess
        cmd = ["python", "panic_simulation.py", video_path]
        if auto_record:
            cmd.extend(["--auto-record", "--record-duration", str(record_duration)])
        
        process = subprocess.Popen(cmd)
        st.text("Panic simulation launched in a separate window.")
        return True
    except Exception as e:
        st.error(f"Error launching panic simulation: {str(e)}")
        return False

def canvas_to_points(canvas_result, width, height):
    """Convert streamlit canvas drawing to points in the original video dimensions"""
    points = []
    if canvas_result and canvas_result.get("objects"):
        for obj in canvas_result.get("objects", []):
            if obj.get("type") == "rect" or obj.get("type") == "polygon":
                # Extract points from the object
                coords = []
                if obj.get("type") == "rect":
                    # For rectangles, get the corner points
                    x = obj.get("left", 0)
                    y = obj.get("top", 0)
                    w = obj.get("width", 0)
                    h = obj.get("height", 0)
                    coords = [(x, y), (x+w, y), (x+w, y+h), (x, y+h)]
                elif obj.get("type") == "polygon":
                    # For polygons, get all points
                    points_data = obj.get("points", [])
                    coords = [(p.get("x", 0), p.get("y", 0)) for p in points_data]
                
                # Convert to original video dimensions if needed
                canvas_width = canvas_result.get("width", width)
                canvas_height = canvas_result.get("height", height)
                
                if canvas_width != width or canvas_height != height:
                    scale_x = width / canvas_width
                    scale_y = height / canvas_height
                    coords = [(int(x * scale_x), int(y * scale_y)) for x, y in coords]
                
                points.append(coords)
    
    return points 