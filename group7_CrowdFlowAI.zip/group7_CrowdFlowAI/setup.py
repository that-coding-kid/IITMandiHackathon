#!/usr/bin/env python3
"""
Setup script for BhedChaal: Crowd Analysis Dashboard
This script:
- Creates necessary directories
- Checks for required dependencies
- Downloads pre-trained models if needed
"""

import os
import sys
import subprocess
import shutil

# Define directory structure
DIRECTORIES = [
    "uploaded_videos",
    "processed_videos",
    "thumbnails",
    "video_data",
    "video_data/areas",
    "video_data/perspective",
    "video_data/objects",
    "video_data/density",
    "video_data/anomalies",
    "panic_sim_results"
]

# Define required Python packages
REQUIRED_PACKAGES = [
    "streamlit",
    "opencv-python",
    "numpy",
    "pandas",
    "ultralytics",
    "scikit-learn",
    "matplotlib",
    "plotly",
    "streamlit-player",
    "streamlit-webrtc",
    "ffmpeg-python",
    "streamlit-drawable-canvas",
    "scipy",
    "python-socketio",
    "watchdog",
    "pillow",
    "pygame"
]

# YOLO models to download
YOLO_MODELS = {
    "small": "yolov8s.pt",
    "medium": "yolov8m.pt",
    "large": "yolov8l.pt",
    "xlarge": "yolov8x.pt"
}

def create_directories():
    """Create all required directories"""
    print("Creating directories...")
    for directory in DIRECTORIES:
        os.makedirs(directory, exist_ok=True)
        print(f"  Created: {directory}/")
    print("Directory structure created successfully!")

def check_dependencies():
    """Check if all required packages are installed"""
    print("Checking dependencies...")
    missing_packages = []
    
    for package in REQUIRED_PACKAGES:
        try:
            __import__(package.replace("-", "_").split(">=")[0].split("==")[0])
            print(f"  ✅ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"  ❌ {package}")
    
    if missing_packages:
        print("\nMissing packages detected. Installing...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
            print("All packages installed successfully!")
        except subprocess.CalledProcessError:
            print("Error installing packages. Please install manually:")
            print(f"  pip install {' '.join(missing_packages)}")
    else:
        print("\nAll required packages are installed!")

def download_yolo_models():
    """Download pre-trained YOLO models"""
    print("Checking for YOLO models...")
    try:
        from ultralytics import YOLO
        for size, model_name in YOLO_MODELS.items():
            try:
                YOLO(model_name)
                print(f"  ✅ {model_name}")
            except Exception:
                print(f"  Downloading {model_name}...")
                YOLO(model_name)
                print(f"  ✅ {model_name} downloaded successfully")
    except ImportError:
        print("  ❌ Ultralytics package not found. Run setup again after installing dependencies.")

def setup_default_config():
    """Create default configuration file"""
    config = {
        "yolo_model_size": "x",
        "use_tracking": True,
        "density_threshold": 0.2,
        "max_points": 200,
        "anomaly_threshold": 30,
        "stampede_threshold": 35,
        "enable_preprocessing": True,
        "auto_cleanup": False,
        "cleanup_days": 7,
        "debug_mode": False
    }
    
    import json
    with open("config.json", "w") as f:
        json.dump(config, f, indent=4)
    
    print("Default configuration file created: config.json")

def main():
    """Main setup function"""
    print("=" * 80)
    print("BhedChaal: Crowd Analysis Dashboard - Setup")
    print("=" * 80)
    
    # Create directories
    create_directories()
    print()
    
    # Check dependencies
    check_dependencies()
    print()
    
    # Download YOLO models
    download_yolo_models()
    print()
    
    # Create default config
    setup_default_config()
    print()
    
    print("=" * 80)
    print("Setup completed successfully!")
    print("You can now run the application with: streamlit run app.py")
    print("=" * 80)

if __name__ == "__main__":
    main() 